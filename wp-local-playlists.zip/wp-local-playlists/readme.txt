WP Local Playlists

Plugin Name: WP Local Playlists
Plugin URI: 
Description: Create local video playlists.
Version: 0.0.1
Tags: Video, Videos, Video Player, Video Playlist, Playlist
Tested up to: 6.0
Requires at least:3.6
Requires PHP: 5.7
PHP Version: 5.7 or higher
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
slug: wp-local-playlists
